from django.shortcuts import render, redirect
from .models import Dishes
from .forms import AddDishes


def index(request):
    dishes = Dishes.objects.all()
    return render(request, 'index.html', context={'dishes': dishes})


def create(request):
    if request.method == "POST":
        dishes = AddDishes(request.POST)
        if dishes.is_valid():
            name = dishes.cleaned_data['name']
            category = dishes.cleaned_data['category']
            price = dishes.cleaned_data['price']
            textarea = dishes.cleaned_data['textarea']
            men, _ = Dishes.objects.get_or_create(name=name, category=category,
                                                  price=price, textarea=textarea)
            return redirect('home')
        else:
            dishes = AddDishes()
            return render(request, 'create.html', context={'dishes': dishes})
    else:
        dishes = AddDishes()
        return render(request, 'craete.html', context={'dishes': dishes})
