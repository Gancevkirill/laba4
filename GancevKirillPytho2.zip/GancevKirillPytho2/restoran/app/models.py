from django.db import models


class Dishes(models.Model):
    name = models.CharField(max_length=10)
    category = models.CharField(max_length=10)
    price = models.IntegerField()
    textarea = models.CharField(max_length=100)

    def str(self):
        return f'{self.name} {self.price}'

    class Meta:
        verbose_name = 'блюдо'
        verbose_name_plural = 'много блюд'
