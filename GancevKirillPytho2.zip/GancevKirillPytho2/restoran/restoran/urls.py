from django.urls import path
from .views import index, create
urlpatterns = [
    path('', index, name='home'),
    path('create/', create, name='create'),
]