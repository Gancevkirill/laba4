from django import forms


class AddDishes(forms.Form):
    name = forms.CharField()
    category = forms.CharField()
    price = forms.IntegerField()
    textarea = forms.CharField()
